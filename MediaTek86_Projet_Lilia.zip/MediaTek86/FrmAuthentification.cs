﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MediaTek86
{
    /// <summary>
    /// Formulaire d’authentification permettant à un utilisateur de se connecter.
    /// </summary>
    public partial class FrmAuthentification : Form
    {
        /// <summary>
        /// Initialise une nouvelle instance de la classe <see cref="FrmAuthentification"/>.
        /// </summary>
        public FrmAuthentification()
        {
            InitializeComponent();
        }
    }
}

