﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MediaTek86
{
    /// <summary>
    /// Formulaire d'affichage des absences du personnel.
    /// </summary>
    public partial class FrmAbsences : Form
    {
        /// <summary>
        /// Initialise une nouvelle instance de la classe <see cref="FrmAbsences"/>.
        /// </summary>
        public FrmAbsences()
        {
            InitializeComponent();
        }
    }
}

