﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MediaTek86
{
    /// <summary>
    /// Formulaire principal de l’application MediaTek.
    /// </summary>
    public partial class FrmMediatek : Form
    {
        /// <summary>
        /// Initialise une nouvelle instance de la classe <see cref="FrmMediatek"/>.
        /// </summary>
        public FrmMediatek()
        {
            InitializeComponent();
        }
    }
}

